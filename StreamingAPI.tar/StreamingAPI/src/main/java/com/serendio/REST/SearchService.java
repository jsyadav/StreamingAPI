package com.serendio.REST;

public class SearchService {

}
